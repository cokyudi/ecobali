<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title> Laravel ajax crud - codechief </title>

    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

</head>
<body>


        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

    </div>
    <script>
        var root_url = <?php echo json_encode(route('data')) ?>;
        var store = <?php echo json_encode(route('regency.store')) ?>;
    </script>
    <?php echo $__env->yieldPushContent('ajax_crud'); ?>
</body>
</html> <?php /**PATH D:\xampp\htdocs\ecobali\resources\views/layouts/app.blade.php ENDPATH**/ ?>
