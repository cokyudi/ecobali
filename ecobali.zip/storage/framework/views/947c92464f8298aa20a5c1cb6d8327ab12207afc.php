
<?php $__env->startSection('participants','active'); ?>

<?php $__env->startPush('css_extend'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>">
<style type="text/css">
    label.error {
        color: red !important;
        text-transform: none !important;
        font-weight: normal !important;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
        <!-- BEGIN: Content-->
        <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-header row mb-1">
                <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
                    <h3 class="content-header-title mb-0 d-inline-block">Create Participant</h3>
                    <div class="row breadcrumbs-top d-inline-block">
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html">Home</a>
                                </li>
                                <li class="breadcrumb-item"><a href="#">Master Data</a>
                                </li>
                                <li class="breadcrumb-item active">Create Participant
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <div class="card">

                    <div class="card-content collapse show">
                        <div class="card-body">

                            <form class="form" id="participantForm" name="participantForm" enctype="multipart/form-data" >
                                <?php echo e(csrf_field()); ?>

                                <div class="form-body">
                                    <input type="hidden" id="participant_id" name="participant_id" value="">
                                    <input type="hidden" id="created_by" name="created_by" value="">
                                    <input type="hidden" id="created_datetime" name="created_datetime" value="">
                                    <input type="hidden" id="last_modified_by" name="last_modified_by" value="">
                                    <input type="hidden" id="last_modified_datetime" name="last_modified_datetime" value="">
                                <div class="nav-vertical">
                                    <ul class="nav nav-tabs nav-left nav-border-left">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab"  href="#tabGeneral" aria-expanded="true">General</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab"  href="#tabLocation" aria-expanded="false">Location</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab"  href="#tabProduct" aria-expanded="false">Product</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" href="#tabPayment" aria-expanded="false">Payment</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" href="#tabOther" aria-expanded="false">Other</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content px-1">
                                        <div class="tab-pane active" id="tabGeneral">
                                            <div class="col-md-12">
                                                <!-- <h4 class="form-section "><i class="la la-user"></i>Name & <i class="la la-street-view"></i>Category</h4> -->
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group form-group-style">
                                                            <label for="participant_name">Participant Name</label>
                                                            <input type="text" id="participant_name" class="form-control" placeholder="Participant Name" name="participant_name"  maxlength="200" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group form-group-style">
                                                            <label for="id_category">Category</label>
                                                            <select id="id_category" name="id_category" class="form-control" required>
                                                                <option value="0" selected="" disabled="">Select Category</option>
                                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- <h4 class="form-section "><i class="la la-book"></i>Contact</h4> -->
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="contact_name_1">Contact Name 1</label>
                                                            <input type="text" id="contact_name_1" class="form-control" placeholder="Contact Name 1" name="contact_name_1"  maxlength="250" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="contact_position_1">Contact Position 1</label>
                                                            <input type="text" id="contact_position_1" class="form-control" placeholder="Contact Position 1" name="contact_position_1"  maxlength="200" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="contact_phone_1">Contact Phone 1</label>
                                                            <input type="number" id="contact_phone_1" class="form-control" placeholder="Contact Phone 1" name="contact_phone_1"  maxlength="50" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="contact_email_1">Contact Email 1</label>
                                                            <input type="email" id="contact_email_1" class="form-control" placeholder="Contact Email 1" name="contact_email_1"  maxlength="200" required>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="contact_name_2">Contact Name 2</label>
                                                            <input type="text" id="contact_name_2" class="form-control" placeholder="Contact Name 2" name="contact_name_2"  maxlength="250" >
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="contact_position_2">Contact Position 2</label>
                                                            <input type="text" id="contact_position_2" class="form-control" placeholder="Contact Position 2" name="contact_position_2"  maxlength="200" >
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="contact_phone_2">Contact Phone 2</label>
                                                            <input type="number" id="contact_phone_2" class="form-control" placeholder="Contact Phone 2" name="contact_phone_2"  maxlength="50" >
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="contact_email_2">Contact Email 2</label>
                                                            <input type="email" id="contact_email_2" class="form-control" placeholder="Contact Email 2" name="contact_email_2"  maxlength="200" >
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- <h4 class="form-section "><i class="la la-bus"></i>Transport Intensity & <i class="la la-calendar"></i>Joined Date</h4> -->
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group form-group-style">
                                                            <label for="id_transport_intensity">Transport Intensity</label>
                                                            <select id="id_transport_intensity" name="id_transport_intensity" class="form-control" required>
                                                                <option value="0" selected="" disabled="">Transport Intensity</option>
                                                                <?php $__currentLoopData = $transport_intensities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transport_intensity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($transport_intensity->id); ?>"><?php echo e($transport_intensity->intensity); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group form-group-style">
                                                            <label for="joined_date">Joined Date</label>
                                                            <input type="date" id="joined_date" class="form-control" name="joined_date" required>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="tab-pane" id="tabLocation" >
                                            <div class="col-md-12">
                                                <!-- <h4 class="form-section "><i class="la la-user"></i>Name & <i class="la la-street-view"></i>Category</h4> -->
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group form-group-style">
                                                            <label for="address">Address</label>
                                                            <input type="text" id="address" class="form-control" placeholder="Address" name="address"  maxlength="400" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- <h4 class="form-section "><i class="la la-book"></i>Contact</h4> -->
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="latitude">Latitude</label>
                                                            <input type="number" id="latitude" class="form-control" placeholder="Latitude" name="latitude"  maxlength="100" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="langitude">Langitude</label>
                                                            <input type="number" id="langitude" class="form-control" placeholder="Langitude" name="langitude"  maxlength="100" required>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="service_area">Service Area</label>
                                                            <input type="text" id="service_area" class="form-control" placeholder="Service Area" name="service_area"  maxlength="400" required>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- <h4 class="form-section "><i class="la la-bus"></i>Transport Intensity & <i class="la la-calendar"></i>Joined Date</h4> -->
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label for="id_area">Area</label>
                                                            <select id="id_area" name="id_area" class="select2 form-control" required>  
                                                                <option value="0" selected="" disabled="">Area</option>
                                                                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($area->id); ?>"><?php echo e($area->area_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group ">
                                                            <label for="id_district">District</label>
                                                            <select id="id_district" name="id_district" class="form-control" required>
                                                                <option value="0" selected="" disabled="">District</option>
                                                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($district->id); ?>"><?php echo e($district->district_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group ">
                                                            <label for="id_regency">Regency</label>
                                                            <select id="id_regency" name="id_regency" class="form-control" required>
                                                                <option value="0" selected="" disabled="">Regency</option>
                                                                <?php $__currentLoopData = $regencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($regency->id); ?>"><?php echo e($regency->regency_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                        <div class="tab-pane" id="tabProduct" >
                                            <div class="col-md-12">
                                                <!-- <h4 class="form-section "><i class="la la-user"></i>Name & <i class="la la-street-view"></i>Category</h4> -->
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group form-group-style">
                                                            <label for="id_box_resource">Box Resources</label>
                                                            <select class="select2 form-control" id="id_box_resource" name="id_box_resource[]" multiple="multiple" required>
                                                                <?php $__currentLoopData = $boxresources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boxresource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($boxresource->id); ?>"><?php echo e($boxresource->resource_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="form-group form-group-style">
                                                            <label for="resource_description">Resource Description</label>
                                                            <input type="text" id="resource_description" class="form-control" placeholder="Resource Description" name="resource_description"  maxlength="400" >
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- <h4 class="form-section "><i class="la la-book"></i>Contact</h4> -->
                                                <div class="row">

                                                </div>

                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="id_purchase_price">Purchase Price</label>
                                                            <select id="id_purchase_price" name="id_purchase_price" class="form-control" required>
                                                                <option value="0" selected="" disabled="">Purchase Price</option>
                                                                <?php $__currentLoopData = $purchase_prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase_price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($purchase_price->id); ?>"><?php echo e($purchase_price->price); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="tab-pane" id="tabPayment">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group form-group-style">
                                                            <label for="id_payment_method">Payment Method</label>
                                                            <select id="id_payment_method" name="id_payment_method" class="form-control" required>
                                                                <option value="0" selected="" disabled="">Payment Method</option>
                                                                <?php $__currentLoopData = $payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($payment_method->id); ?>"><?php echo e($payment_method->payment_method); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group form-group-style">
                                                            <label for="id_bank">Bank</label>
                                                            <select id="id_bank" name="id_bank" class="form-control" required>
                                                                <option value="0" selected="" disabled="">Bank</option>
                                                                <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->bank_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group ">
                                                            <label for="bank_branch">Bank Branch</label>
                                                            <input type="text" id="bank_branch" class="form-control" placeholder="Bank Branch" name="bank_branch"  maxlength="200" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group ">
                                                            <label for="bank_account_number">Bank Account Number</label>
                                                            <input type="number" id="bank_account_number" class="form-control" name="bank_account_number"  maxlength="200" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group ">
                                                            <label for="bank_account_holder_name">Bank Account Holder Name</label>
                                                            <input type="text" id="bank_account_holder_name" class="form-control" placeholder="Bank Account Holder Name" name="bank_account_holder_name"  maxlength="200" required>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>

                                        <div class="tab-pane" id="tabOther" >
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group form-group-style">
                                                            <label for="notes">Notes</label>
                                                            <input type="text" id="notes" class="form-control" placeholder="Notes" name="notes"  maxlength="400" >
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="row">
                                                            <div class="col-md-12 mb-2">
                                                                <div class="form-group">
                                                                    <label for="url_photo_1">Attach a photograph</label>
                                                                    <input type="file" name="url_photo_1" id="url_photo_1" accept="image/*" class="form-control-file">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12 mb-2">
                                                                <img id="preview-image1-before-upload" data-toggle="modal" data-target="#modalImage1" class="img-thumbnail img-fluid" src="https://www.riobeauty.co.uk/images/product_image_not_found.gif"
                                                                     alt="preview image" style="display: block; margin-left: auto; margin-right: auto;  max-height: 300px">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="row">
                                                            <div class="col-md-12 mb-2">
                                                                <fieldset class="form-group">
                                                                    <div class="custom-file">
                                                                        <label for="url_photo_2">Attach a photograph</label>
                                                                        <input type="file" name="url_photo_2" id="url_photo_2" accept="image/*" class="form-control-file">
                                                                    </div>
                                                                </fieldset>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12 mb-2">
                                                                <img id="preview-image2-before-upload" data-toggle="modal" data-target="#modalImage2" class="img-thumbnail img-fluid" src="https://www.riobeauty.co.uk/images/product_image_not_found.gif"
                                                                     alt="preview image" style="display: block; margin-left: auto; margin-right: auto;  max-height: 300px">
                                                            </div>
                                                        </div>

                                                    </div>

                                                    <div class="modal fade text-left" id="modalImage1" tabindex="-1" role="dialog" >
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-body">
                                                                <img id="imageModal1" src="https://www.riobeauty.co.uk/images/product_image_not_found.gif" alt="" style="display: block; max-height: 700px">
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <div class="modal fade text-left" id="modalImage2" tabindex="-1" role="dialog" >
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-body">
                                                                <img id="imageModal2" src="https://www.riobeauty.co.uk/images/product_image_not_found.gif" alt="" style="display: block; max-height: 700px">
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                </div>

                                <div class="form-actions text-right">
                                    <button id='backBtn' type="button" class="btn btn-warning mr-1">
                                        <i class="ft-x"></i> Cancel
                                    </button>
                                    <button id="saveBtn"  value="create"  type="submit" class="btn btn-primary">
                                        <i class="la la-check-square-o"></i> Save
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('ajax_crud'); ?>
<script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts/forms/select/form-select2.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function(e) {
        var form = $("#participantForm");
        form.validate();

        $('#url_photo_1').change(function() {
            let reader = new FileReader();
            reader.onload = (e) => {
                $('#preview-image1-before-upload').attr('src', e.target.result);
                $('#imageModal1').attr('src', e.target.result);
            }
            reader.readAsDataURL(this.files[0]);
            var filename = $('#url_photo_1')[0].files[0];
            $('#url_photo_1_label').html(filename.name);

        });

        $('#url_photo_2').change(function() {
            let reader = new FileReader();
            reader.onload = (e) => {
                $('#preview-image2-before-upload').attr('src', e.target.result);
                $('#imageModal2').attr('src', e.target.result);
            }
            reader.readAsDataURL(this.files[0]);
            var filename = $('#url_photo_2')[0].files[0];
            $('#url_photo_2_label').html(filename.name);

        });

    });
</script>
<script type="text/javascript">
    $(function() {
        // $('#id_box_resource').val(['AK', 'AB']).change(); //select multiple select
        //alert("Selected value is: "+$("#id_box_resource").val());
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#backBtn').click(function() {
            console.log(new FormData($("#participantForm")[0]));
            
        });

        $('#saveBtn').click(function(e) {
            if ($('#participantForm').valid()) {
                e.preventDefault();
                if ($('#saveBtn').val() == "create")  {
                    $('#created_by').val("Deva Dwi A");
                    $('#created_datetime').val(new Date().toISOString().slice(0, 19).replace('T', ' '));
                    $('#last_modified_by').val(null);
                    $('#last_modified_datetime').val(null);
                    var alertMessage = 'Participant berhasil ditambahkan.';
                } else {
                    $('#last_modified_by').val("Deva Dwi A Edit");
                    $('#last_modified_datetime').val(new Date().toISOString().slice(0, 19).replace('T', ' '));
                    var alertMessage = 'Participant berhasil di edit.';
                }
                $(this).html('Save');

                $.ajax({
                    data: new FormData($("#participantForm")[0]),
                    url: "<?php echo e(route('participants.store')); ?>",
                    type: "POST",
                    dataType: 'json',
                    processData: false,
                    contentType: false,
                    success: function (dataResult) {
                        $('#saveBtn').val("modify");
                        $('#saveBtn').html('Save Changes');
                        $('#participant_id').val(dataResult.data.id);
                        $('#created_by').val(dataResult.data.created_by);
                        $('#created_datetime').val(dataResult.data.created_datetime);
                        toastr.options = {
                            "positionClass": "toast-bottom-right"
                        };
                        toastr.success(alertMessage);

                        // $('#paymentMethodForm').trigger("reset");
                    },
                    error: function (data) {
                        toastr.error('Gagal menambahkan data.');
                        console.log('Error:', data);
                        $('#saveBtn').html('Save Changes');
                    }
                });
            }
            

        });
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('template', ['user'=>$user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecobali\resources\views/participant/create.blade.php ENDPATH**/ ?>