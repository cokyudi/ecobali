<?php $__env->startSection('users','active'); ?>

<?php $__env->startPush('menu_title'); ?>
    <li class="nav-item d-none d-lg-block">
        <a class="nav-link text-bold-700 font-medium-3" href="<?php echo e(url('user-management')); ?>">User Management</a>
    </li>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
        <!-- BEGIN: Content-->
        <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-body">
                <!-- Zero configuration table -->
                <section id="configuration">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header pb-0">
                                    <h4 class="card-title">User Management</h4>
                                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                            <li><a data-action="close"><i class="ft-x"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <?php if(session('errors')): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        Something it's wrong:
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                        <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(Session::has('error')): ?>
                                    <div class="alert alert-danger">
                                        <?php echo e(Session::get('error')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="card-content collapse show">
                                    <div class="card-body card-dashboard">
                                        <button type="button" class="btn btn-success btn-min-width mr-1 mb-1" href="javascript:void(0)" id="createNewUser">Add New User</button>
                                        <?php echo $__env->make('userManagement.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="table-responsive">
                                            <table id="userTable" class="table table-striped table-bordered zero-configuration">
                                                <thead>
                                                    <tr>
                                                        <th width="30px">No</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Role</th>
                                                        <th width="250px">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th width="30px">No</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Role</th>
                                                        <th width="250px">Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!--/ Zero configuration table -->
            </div>
        </div>
    </div>
        <!-- END: Content -->
        <?php $__env->stopSection(); ?>

<?php $__env->startPush('ajax_crud'); ?>
<script type="text/javascript">
  $(function () {

    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
      });

      var table = $('#userTable').DataTable({
          processing: true,
          serverSide: true,
          ajax: "<?php echo e(route('user-management.index')); ?>",
          columns: [
              {data: null},
              {data: 'name', name: 'name'},
              {data: 'email', name: 'email'},
              {data: 'role', name: 'role'},
              {data: 'action', name: 'action', orderable: false, searchable: false},
          ]
      });

      table.on('draw.dt', function () {
            var info = table.page.info();
            table.column(0, { search: 'applied', order: 'applied', page: 'applied' }).nodes().each(function (cell, i) {
                cell.innerHTML = i + 1 + info.start;
            });
        });

      $('#createNewUser').click(function () {
          $('#saveBtn').val("create");
          $('#user_id').val('');
          $('#userForm').trigger("reset");
          $('#modalHeading').html("Create New User");
          $('#email').removeAttr('disabled');
          $('#password').removeAttr('disabled');
          $('#password_confirmation').removeAttr('disabled');
          $('#password-form').show();
          $('#password_confirmation-form').show();
          $('#role').removeAttr('readonly');
          $('#userModal').modal('show');
      });

      $('body').on('click', '.editUser', function () {
        var user_id = $(this).data('id');
        var loginUser_id = <?=$user->id;?>;
        $('#role').removeAttr('readonly');

        $.get("<?php echo e(route('user-management.index')); ?>" +'/' + user_id +'/edit', function (data) {
            $('#modalHeading').html("Edit User");
            $('#saveBtn').val("edit");
            $('#userModal').modal('show');
            $('#user_id').val(data.id);
            $('#name').val(data.name);
            $('#email').val(data.email);
            $('#email').attr('disabled','disabled');
            $('#password').attr('disabled','disabled');
            $('#password_confirmation').attr('disabled','disabled');
            $('#password-form').hide();
            $('#password_confirmation-form').hide();
            $('#role').val(data.role);
            $('#created_by').val(data.created_by);
            $('#created_datetime').val(data.created_datetime);
            $('#last_modified_by').val(data.last_modified_by);
            $('#last_modified_datetime').val(data.last_modified_datetime);

            if (loginUser_id === user_id) {
                $('#role').attr('readonly', 'readonly');
            }
        })
     });

      $('#saveBtn').click(function (e) {
        toastr.clear();
        var nameField = $('#name').val();
        if (nameField == '') {
            toastr.options = {
                "closeButton": true,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "0",
                "hideDuration": "0"
            }
            toastr.error('Nama tidak boleh kosong.');
            $('#saveBtn').html('Save Changes');
            return;
        }
          e.preventDefault();
          if ($('#saveBtn').val() == "create")  {
              $('#created_by').val("Deva Dwi A");
              $('#created_datetime').val(new Date().toISOString().slice(0, 19).replace('T', ' '));
              $('#last_modified_by').val(null);
              $('#last_modified_datetime').val(null);
              var alertMessage = 'User berhasil ditambahkan.';
          } else {
             $('#created_by').val("Deva Dwi A");
              $('#created_datetime').val(new Date().toISOString().slice(0, 19).replace('T', ' '));
              $('#last_modified_by').val("Deva Dwi A Edit");
              $('#last_modified_datetime').val(new Date().toISOString().slice(0, 19).replace('T', ' '));
              var alertMessage = 'User berhasil di edit.';
          }
          $(this).html('Save');

          $.ajax({
            data: $('#userForm').serialize(),
            url: "<?php echo e(route('user-management.store')); ?>",
            type: "POST",
            dataType: 'json',
            success: function (data) {
                toastr.clear()
                if (data.error) {
                    let messages = '';
                    toastr.options = {
                        "closeButton": true,
                        "positionClass": "toast-top-center",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "0",
                        "hideDuration": "0"
                    }
                    if (data.errors.name) {
                        messages = messages + '<li>'+data.errors.name+'</li>'
                    }
                    if (data.errors.email) {
                        messages = messages + '<li>'+data.errors.email+'</li>'
                    }
                    if (data.errors.password) {
                        messages = messages + '<li>'+data.errors.password+'</li>'
                    }
                    toastr.error(messages,data.error);
                    $('#saveBtn').html('Save Changes');
                    return;
                }

                $('#userForm').trigger("reset");
                $('#userModal').modal('hide');
                var loginUser_id = <?=$user->id;?>;
                if (data.editedUser && loginUser_id == data.editedUser.user_id) {
                    $('#user-identity').html(data.editedUser.name + ' / ' + data.editedUser.role);
                }
                toastr.options = {
                    "positionClass": "toast-bottom-right"
                };
                toastr.success(alertMessage);
                table.draw();

            },
            error: function (data) {
                console.log('Error:', data);
                $('#saveBtn').html('Save Changes');
            }
        });
      });

      $('body').on('click', '.deleteUser', function () {

        var area_id = $(this).data("id");
        swal({
            title: "Are you sure?",
            text: "Apakah anda yakin untuk menghapus data ini ?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: "DELETE",
                    url: "<?php echo e(route('user-management.store')); ?>"+'/'+area_id,
                    success: function (data) {
                        toastr.options = {
                            "positionClass": "toast-bottom-right"
                        }
                        toastr.success('User berhasil dihapus.');
                        table.draw();
                    },
                    error: function (data) {
                        console.log('Error:', data);
                    }
                });
            } else {}
        });

      });

    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('template', ['user'=>$user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecobali\resources\views/userManagement/index.blade.php ENDPATH**/ ?>